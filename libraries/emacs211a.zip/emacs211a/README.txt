This is the Emacs 2.11 distribution
===================================

Files in the archive
--------------------

README             This file
INSTALL            Fast installation guide
EMACS.49G          The main library for the HP49G hp48gII.
EMACS.49GP         The main library for the hp49g+
SDIAG.49G          Library with database of stack diagrams, for HP49G, hp48gII
SDIAG.49GP         Library with database of stack diagrams, for hp49g+
extable2.lib       Extended extable library (provided by Thomas Rast)

Docs/Refcard.pdf   Printable command summary on a single page.
Docs/Emacs2.htm    Main Documentation file
Docs/images        Screenshots for the documentation
Docs/Locate.txt    Documentation for LOCATE.  By Denis Martinez.
Docs/SDIAG.txt     Additional info about the Stack Diagram Database.
                   There are 2 versions of this file, for the 2 SDIAG versions.
Docs/Romptr.txt    All Emacs Rompointers, with stack diagrams.

Misc/SD.ULSCMR     Same as the SDIAG.49G library in the main directory
Misc/SD.UL    -|
Misc/SD.ULMR   |   Smaller versions of the SDIAG.49G library, with some
Misc/SD.ULS    |   entries removed.  The letters after the dot mean:
Misc/SD.ULSC   |   U  UserRPL commands          C  CAS-related SysRPL
Misc/SD.ULSMR  |   L  Library 256-258           M  ML entries
Misc/SD.UMR  __|   S  SysRPL (except CAS)       R  RAM entries

Src/DEVEL.DIR      The directory which contains the Emacs source
                   code and tools needed to compile it (on the HP49G).
Src/README         Minimal documentation of the development directory.